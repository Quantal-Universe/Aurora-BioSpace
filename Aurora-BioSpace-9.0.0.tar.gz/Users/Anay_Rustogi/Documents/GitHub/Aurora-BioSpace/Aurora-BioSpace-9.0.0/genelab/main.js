process.env.ELECTRON_DISABLE_SECURITY_WARNINGS = 'true';

const { app, BrowserWindow, ipcMain, shell, session } = require('electron');
const path = require('path');
const { spawn } = require('child_process');
const { OAuth2Client } = require('google-auth-library');
const fs = require('fs');
const http = require('http');
const { generateVerifier, generateChallenge } = require('./utils/auth');

let mainWindow;
let proxyProcess;
let oAuth2Client = {
    credentials: {}
};
let isAuthenticated = false;
let authProvider = null; 
let pollinationsApiKey = null;
let quantalUsername = 'QuantalUser';

// Third-party script error patterns from embedded NASA/WordPress webviews that
// are harmless to our app and should not pollute the DevTools or terminal console.
const WEBVIEW_NOISE_PATTERNS = [
  'setLocaleData',
  'wp-i18n',
  'wp-i18n-js-after',
  'JQMIGRATE',
  'Migrate is installed',
  'Insecure Content-Security-Policy',
  'electronjs.org/docs/tutorial/security',
  'sandbox_bundle',
  'unsafe-eval'
];

// Attach handler to all WebContents (main window, popups, and <webview> guests)
app.on('web-contents-created', (event, contents) => {
  contents.on('console-message', (e, level, message, line, sourceId) => {
    const text = (message || '').toString();
    const src = (sourceId || '').toString();
    if (WEBVIEW_NOISE_PATTERNS.some(pattern => text.includes(pattern) || src.includes(pattern))) {
      e.preventDefault();
    }
  });

  if (contents.getType() === 'webview') {
    contents.on('did-start-navigation', () => {
      contents.executeJavaScript(`
        window.wp = window.wp || {};
        window.wp.i18n = window.wp.i18n || {
          setLocaleData: function() {},
          __: function(s) { return s; },
          _x: function(s) { return s; },
          _n: function(s, p, n) { return n === 1 ? s : p; },
          _nx: function(s, p, n) { return n === 1 ? s : p; },
          isRtl: function() { return false; },
          hasLocaleData: function() { return true; }
        };
      `).catch(() => {});
    });
  }
});

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400, height: 900,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webviewTag: true
    },
    frame: false,
    backgroundColor: '#050505'
  });

  mainWindow.webContents.on('console-message', (event, level, message, line, sourceId) => {
    const text = (message || '').toString();
    const src = (sourceId || '').toString();
    if (WEBVIEW_NOISE_PATTERNS.some(pattern => text.includes(pattern) || src.includes(pattern))) {
      event.preventDefault();
    }
  });

  mainWindow.loadFile('intro.html');
}

const sessionPath = path.join(__dirname, 'session.bin');

function saveSession(data) {
    if (pollinationsApiKey && !data.pollinationsApiKey) {
        data.pollinationsApiKey = pollinationsApiKey;
    }
    if (quantalUsername && !data.quantalUsername) {
        data.quantalUsername = quantalUsername;
    }
    fs.writeFileSync(sessionPath, JSON.stringify(data));
}

function loadSession() {
    if (fs.existsSync(sessionPath)) {
        try {
            const data = JSON.parse(fs.readFileSync(sessionPath));
            isAuthenticated = true;
            authProvider = data.provider;
            if (data.pollinationsApiKey) {
                pollinationsApiKey = data.pollinationsApiKey;
            }
            if (data.quantalUsername) {
                quantalUsername = data.quantalUsername;
            } else if (data.user && data.user.name) {
                quantalUsername = data.user.name;
            }
            if (authProvider === 'google') {
                oAuth2Client.credentials = data.tokens || {};
            }
            return { 
                isLoggedIn: true, 
                provider: authProvider, 
                user: { name: quantalUsername },
                pollinationsApiKey: pollinationsApiKey 
            };
        } catch (e) {
            console.error("Failed to load session", e);
        }
    }
    return { isLoggedIn: false };
}

function clearSession() {
    pollinationsApiKey = null;
    quantalUsername = 'QuantalUser';
    if (fs.existsSync(sessionPath)) {
        fs.unlinkSync(sessionPath);
    }
}

app.whenReady().then(() => {
  // Configure WebAuthn / Passkey support on macOS
  if (process.platform === 'darwin' && typeof app.configureWebAuthn === 'function') {
    try {
      app.configureWebAuthn({
        touchID: {
          promptReason: 'Sign in with your Passkey'
        }
      });
      console.log('DEBUG: app.configureWebAuthn enabled');
    } catch (e) {
      console.log('DEBUG: app.configureWebAuthn note:', e.message);
    }
  }

  // Handle WebAuthn account selection (Electron 42+)
  session.defaultSession.on('select-webauthn-account', (event, details, callback) => {
    console.log('DEBUG: select-webauthn-account called:', details?.relyingPartyId, 'accounts:', details?.accounts?.length);
    try {
      if (details && details.accounts && details.accounts.length > 0) {
        callback(details.accounts[0].credentialId);
      } else {
        callback();
      }
    } catch (err) {
      console.error('DEBUG: Error in select-webauthn-account callback:', err);
      callback();
    }
  });

  // Handle select-credential
  session.defaultSession.on('select-credential', (event, details, callback) => {
    console.log('DEBUG: select-credential called:', details);
    if (event && event.preventDefault) event.preventDefault();
    try {
      if (details && details.credentialList && details.credentialList.length > 0) {
        callback(details.credentialList[0].credentialId);
      } else {
        callback();
      }
    } catch (err) {
      console.error('DEBUG: Error in select-credential callback:', err);
      callback();
    }
  });

  // Global permission handlers for WebAuthn, Bluetooth, and media
  session.defaultSession.setPermissionRequestHandler((webContents, permission, callback) => {
    console.log('DEBUG: Permission requested on defaultSession:', permission);
    callback(true);
  });

  session.defaultSession.setPermissionCheckHandler((webContents, permission, requestingOrigin, details) => {
    return true;
  });

  session.defaultSession.setDevicePermissionHandler((details) => {
    return true;
  });

  if (typeof session.defaultSession.setBluetoothPairingHandler === 'function') {
    session.defaultSession.setBluetoothPairingHandler((details, callback) => {
      console.log('DEBUG: Bluetooth pairing request on defaultSession:', details);
      callback({ response: 'confirm' });
    });
  }

  const proxyPath = path.join(__dirname, 'proxy.js');
  
  function startProxy() {
      proxyProcess = spawn('node', [proxyPath], { cwd: __dirname, detached: false });
      
      proxyProcess.on('error', (err) => {
        console.error(`DEBUG: Failed to start proxy process: ${err.message}`);
      });

      proxyProcess.on('close', (code) => {
        console.log(`DEBUG: Proxy process exited with code ${code}. Restarting in 5s...`);
        setTimeout(startProxy, 5000); // Add a delay to prevent rapid crash-loops
      });
      
      proxyProcess.stdout.on('data', (data) => console.log(`Proxy: ${data}`));
      proxyProcess.stderr.on('data', (data) => console.error(`Proxy Error: ${data}`));
  }
  
  startProxy();
  
  loadSession();
  setupHandlers();
  createWindow();
});

function openExternalCrossPlatform(targetUrl) {
  console.log("DEBUG: openExternalCrossPlatform opening:", targetUrl);
  let isWSL = false;
  if (process.platform === 'linux') {
    try {
      if (process.env.WSL_DISTRO_NAME || process.env.WSL_INTEROP) {
        isWSL = true;
      } else if (fs.existsSync('/proc/version')) {
        const procVersion = fs.readFileSync('/proc/version', 'utf8').toLowerCase();
        if (procVersion.includes('microsoft') || procVersion.includes('wsl')) {
          isWSL = true;
        }
      }
    } catch (e) {}
  }

  if (isWSL) {
    try {
      const wslview = spawn('wslview', [targetUrl], { detached: true });
      wslview.on('error', () => {
        const ps = spawn('powershell.exe', ['-c', `Start-Process '${targetUrl}'`], { detached: true });
        ps.on('error', () => {
          spawn('cmd.exe', ['/c', 'start', '""', targetUrl], { detached: true });
        });
      });
      return;
    } catch (e) {}
  }

  shell.openExternal(targetUrl).catch((err) => {
    console.warn('DEBUG: shell.openExternal failed, using fallback:', err.message);
    if (process.platform === 'linux') {
      spawn('xdg-open', [targetUrl], { detached: true });
    } else if (process.platform === 'darwin') {
      spawn('open', [targetUrl], { detached: true });
    }
  });
}

async function startOAuthFlow() {
  const verifier = generateVerifier();
  const challenge = generateChallenge(verifier);
  const clientId = '1073478097806-e1uppnsvsmddbqp1hifdt2s8iqjrp7ns.apps.googleusercontent.com';
  const redirectUri = 'http://localhost:3000';
  const scope = 'openid email profile https://www.googleapis.com/auth/generative-language.tuning';
  
  const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?` +
    `client_id=${clientId}&` +
    `redirect_uri=${encodeURIComponent(redirectUri)}&` +
    `response_type=code&` +
    `scope=${encodeURIComponent(scope)}&` +
    `code_challenge=${challenge}&` +
    `code_challenge_method=S256`;

  return new Promise((resolve, reject) => {
    // Fresh session partition to prevent stale passkey errors or cached loops
    const googleAuthSession = session.fromPartition('google-auth-' + Date.now(), { cache: false });

    let authWindow = new BrowserWindow({ 
        width: 600, 
        height: 800, 
        title: 'Sign in with Google',
        webPreferences: { 
            nodeIntegration: false, 
            contextIsolation: true,
            webSecurity: true,
            session: googleAuthSession,
            preload: path.join(__dirname, 'utils', 'google-auth-preload.js')
        }
    });

    let codeProcessed = false;
    let browserHandoff = false;

    authWindow.webContents.on('did-fail-load', (event, errorCode, errorDescription) => {
        console.error(`DEBUG: Auth window failed to load: ${errorDescription} (${errorCode})`);
    });

    // Function to open the flow in the default browser when passkey is detected
    const openInDefaultBrowser = (userEmail = '') => {
        if (browserHandoff) return;
        browserHandoff = true;
        console.log("DEBUG: Google Passkey detected! Opening default browser. Email hint:", userEmail);

        let targetUrl = authUrl;
        if (userEmail && userEmail.includes('@')) {
            targetUrl += `&login_hint=${encodeURIComponent(userEmail)}`;
        }

        openExternalCrossPlatform(targetUrl);

        if (authWindow && !authWindow.isDestroyed()) {
            authWindow.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(`
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset="utf-8">
                    <title>Authenticating with Passkey</title>
                    <style>
                        body {
                            background: #0f172a;
                            color: #f8fafc;
                            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            height: 100vh;
                            margin: 0;
                            padding: 20px;
                            box-sizing: border-box;
                        }
                        .card {
                            background: #1e293b;
                            padding: 36px 28px;
                            border-radius: 16px;
                            border: 1px solid #334155;
                            text-align: center;
                            max-width: 440px;
                            box-shadow: 0 10px 30px rgba(0,0,0,0.5);
                        }
                        .icon { font-size: 44px; margin-bottom: 16px; }
                        h2 { color: #38bdf8; margin: 0 0 12px 0; font-size: 20px; }
                        p { color: #94a3b8; font-size: 14px; line-height: 1.6; margin: 0 0 24px 0; }
                        .badge {
                            display: inline-flex;
                            align-items: center;
                            gap: 8px;
                            background: rgba(56, 189, 248, 0.12);
                            color: #38bdf8;
                            padding: 8px 18px;
                            border-radius: 20px;
                            font-size: 13px;
                            font-weight: 500;
                        }
                        .dot {
                            width: 8px;
                            height: 8px;
                            background: #38bdf8;
                            border-radius: 50%;
                            box-shadow: 0 0 8px #38bdf8;
                        }
                        .btn {
                            display: inline-block;
                            margin-top: 24px;
                            color: #64748b;
                            font-size: 12px;
                            text-decoration: underline;
                            cursor: pointer;
                        }
                    </style>
                </head>
                <body>
                    <div class="card">
                        <div class="icon">🔑</div>
                        <h2>Passkey Authentication</h2>
                        <p>Google is requesting your passkey. We've opened your default browser to verify your fingerprint, face, or screen lock securely.</p>
                        <div class="badge">
                            <div class="dot"></div>
                            Waiting for verification from browser...
                        </div>
                        <div>
                            <span class="btn" onclick="window.close()">Close window</span>
                        </div>
                    </div>
                </body>
                </html>
            `)}`);
        }
    };

    const onPasskeyDetected = (event, data) => {
        console.log("DEBUG: Main process caught google-passkey-detected event:", data);
        openInDefaultBrowser(data?.email);
    };
    ipcMain.once('google-passkey-detected', onPasskeyDetected);

    // Also monitor navigation and DOM on authWindow for passkey screens
    const checkPasskeyInPage = async () => {
        if (browserHandoff) return;
        try {
            const res = await authWindow.webContents.executeJavaScript(`
                (function() {
                    var t = (document.body && document.body.innerText) || '';
                    var has = t.includes('Use your passkey') ||
                              t.includes('fingerprint, face, or screen lock') ||
                              t.includes('Make sure Bluetooth is on') ||
                              window.location.href.includes('challenge/pk');
                    var email = '';
                    if (has) {
                        var m = t.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}/);
                        if (m) email = m[0];
                    }
                    return { has: has, email: email };
                })()
            `);
            if (res && res.has) {
                openInDefaultBrowser(res.email);
            }
        } catch(e) {}
    };

    authWindow.webContents.on('did-finish-load', checkPasskeyInPage);
    authWindow.webContents.on('did-navigate', checkPasskeyInPage);
    authWindow.webContents.on('did-navigate-in-page', checkPasskeyInPage);

    // If Google requests Bluetooth device, trigger handoff to browser where Bluetooth caBLE works
    authWindow.webContents.on('select-bluetooth-device', (event, deviceList, callback) => {
        event.preventDefault();
        try { callback(''); } catch(e) {}
        openInDefaultBrowser();
    });

    const server = http.createServer(async (req, res) => {
        const url = new URL(req.url, `http://${req.headers.host}`);
        const code = url.searchParams.get('code');
        console.log("DEBUG: HTTP Server received request:", req.url);
        
        if (code && !codeProcessed) {
            codeProcessed = true;
            console.log("DEBUG: Auth code received in HTTP server:", code);
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(`
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset="utf-8">
                    <title>Authentication Successful</title>
                    <style>
                        body {
                            background: #0f172a;
                            color: #f8fafc;
                            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            height: 100vh;
                            margin: 0;
                        }
                        .box {
                            background: #1e293b;
                            padding: 36px 32px;
                            border-radius: 16px;
                            border: 1px solid #334155;
                            text-align: center;
                            max-width: 420px;
                            box-shadow: 0 10px 30px rgba(0,0,0,0.5);
                        }
                        h2 { color: #38bdf8; margin: 0 0 12px 0; }
                        p { color: #94a3b8; font-size: 14px; margin: 0 0 16px 0; line-height: 1.5; }
                        .check { font-size: 40px; margin-bottom: 12px; }
                    </style>
                </head>
                <body>
                    <div class="box">
                        <div class="check">✅</div>
                        <h2>Authentication Successful!</h2>
                        <p>Your passkey was verified. You can close this tab and return to <strong>Aurora BioSpace</strong>.</p>
                    </div>
                </body>
                </html>
            `);
            server.close();
            
            // Try closing the window safely
            if (authWindow && !authWindow.isDestroyed()) {
                console.log("DEBUG: Closing auth window");
                authWindow.close();
            }
            authWindow = null;
            
            console.log("DEBUG: Sending verifier to proxy:", verifier);
            
            const RECOVERABLE = new Set(['ECONNRESET','EPIPE','ECONNABORTED','ETIMEDOUT','EAI_AGAIN']);
            const exchangeWithRetry = async (retries = 3) => {
                let lastErr;
                for (let attempt = 1; attempt <= retries; attempt++) {
                    try {
                        const response = await fetch('https://quantal-labs.com/google-auth/aurora-biospace-auth/auth', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ code: code, redirectUri: redirectUri, codeVerifier: verifier })
                        });
                        const rawResponse = await response.text();
                        console.log('DEBUG: Raw response from proxy:', rawResponse);
                        let tokens;
                        try { tokens = JSON.parse(rawResponse); }
                        catch (e) { throw new Error('Failed to parse proxy response as JSON'); }
                        if (!tokens.access_token) throw new Error('No access_token in proxy response');
                        return tokens;
                    } catch (err) {
                        lastErr = err;
                        const isRecoverable = RECOVERABLE.has(err.code) ||
                            (err.message || '').includes('connection reset') ||
                            (err.message || '').includes('stream reading error');
                        if (isRecoverable && attempt < retries) {
                            const delay = 600 * attempt;
                            console.error(`DEBUG: Token exchange attempt ${attempt} failed (${err.code || err.message}), retrying in ${delay}ms...`);
                            await new Promise(r => setTimeout(r, delay));
                            continue;
                        }
                        throw err;
                    }
                }
                throw lastErr;
            };

            try {
                const tokens = await exchangeWithRetry();
                oAuth2Client.credentials = tokens;
                isAuthenticated = true;
                authProvider = 'google';
                saveSession({ provider: 'google', tokens: oAuth2Client.credentials });
                if (mainWindow) {
                    mainWindow.webContents.send('auth-update', { isLoggedIn: true, provider: 'google' });
                }
                console.log('DEBUG: Auth success, resolving promise');
                resolve({ isLoggedIn: true, user: { name: 'User' } });
            } catch (err) {
                console.error('DEBUG: Token exchange failed after retries:', err.message || err);
                isAuthenticated = false;
                authProvider = null;
                reject(err);
            }
        } else if (codeProcessed) {
            console.log("DEBUG: Code already processed, ignoring request");
            res.end('Authentication already processed.');
        } else {
            console.log("DEBUG: No code found in callback, URL:", req.url);
            res.end('No code found.');
        }
    });

    server.listen(3000, () => {
        authWindow.loadURL(authUrl);
    });

    authWindow.on('closed', () => {
        ipcMain.removeListener('google-passkey-detected', onPasskeyDetected);
        authWindow = null;
        if (!codeProcessed && !browserHandoff) {
            try {
                if (server.listening) server.close();
            } catch (e) {}
            codeProcessed = true;
            resolve({ isLoggedIn: false, cancelled: true });
        } else if (browserHandoff && !codeProcessed) {
            console.log("DEBUG: Auth window closed during browser handoff, keeping local server alive for 180s...");
            setTimeout(() => {
                if (!codeProcessed) {
                    codeProcessed = true;
                    try { if (server.listening) server.close(); } catch (e) {}
                    resolve({ isLoggedIn: false, cancelled: true, timeout: true });
                }
            }, 180000);
        }
    });
  });
}

function setupHandlers() {
  ipcMain.handle('get-auth-status', () => ({ 
      isLoggedIn: isAuthenticated, 
      provider: authProvider,
      user: isAuthenticated ? (authProvider === 'quantal' ? { name: quantalUsername } : { name: 'User' }) : null,
      pollinationsApiKey: pollinationsApiKey
  }));

  ipcMain.handle('google-oauth-login', async () => {
      return await startOAuthFlow();
  });

  ipcMain.handle('quantal-oauth-login', async () => {
      return new Promise((resolve) => {
          let resolved = false;
          let attemptedUsername = '';

          // Use an isolated in-memory session per auth attempt to avoid listener leaks
          const quantalSession = session.fromPartition('quantal-auth-' + Date.now(), { cache: false });

          // Handle passkey selection for Quantal session if triggered
          quantalSession.on('select-webauthn-account', (event, details, callback) => {
              try {
                  if (details && details.accounts && details.accounts.length > 0) {
                      callback(details.accounts[0].credentialId);
                  } else {
                      callback();
                  }
              } catch (e) {
                  callback();
              }
          });
          quantalSession.on('select-credential', (event, details, callback) => {
              if (event && event.preventDefault) event.preventDefault();
              try {
                  if (details && details.credentialList && details.credentialList.length > 0) {
                      callback(details.credentialList[0].credentialId);
                  } else {
                      callback();
                  }
              } catch (e) {
                  callback();
              }
          });

          const authWindow = new BrowserWindow({ 
              width: 600, 
              height: 800, 
              title: 'Sign in with Quantal Labs',
              webPreferences: { 
                  nodeIntegration: false, 
                  contextIsolation: true,
                  session: quantalSession
              }
          });

          // Grant bluetooth permission so WebAuthn hybrid (cross-device) passkey transport works
          quantalSession.setPermissionRequestHandler((webContents, permission, callback) => {
              if (permission === 'bluetooth' || permission === 'media') {
                  callback(true);
              } else {
                  callback(false);
              }
          });

          // Only disable the unsolicited passkey autofill popup (before user interaction).
          // Do NOT override navigator.credentials.get or platform authenticator — passkeys must work.
          authWindow.webContents.on('did-finish-load', () => {
              authWindow.webContents.executeJavaScript(`
                  try {
                      if (window.PublicKeyCredential &&
                          typeof PublicKeyCredential.isConditionalMediationAvailable === 'function') {
                          PublicKeyCredential.isConditionalMediationAvailable = () => Promise.resolve(false);
                      }
                      const loginForm = document.getElementById('loginForm');
                      if (loginForm && !loginForm._tracked) {
                          loginForm._tracked = true;
                          loginForm.addEventListener('submit', () => {
                              const u = document.getElementById('username')?.value;
                              if (u && u.trim()) window._lastAttemptedUsername = u.trim();
                          });
                      }
                  } catch(e) {}
              `).catch(() => {});
          });

          // Intercept POST request body to extract the real username submitted by the user
          try {
              quantalSession.webRequest.onBeforeRequest(
                  { urls: ['https://authentication.quantal-labs.com/login*'] },
                  (details, callback) => {
                      if (details.method === 'POST' && details.uploadData && details.uploadData.length > 0) {
                          try {
                              const postBody = details.uploadData[0].bytes ? details.uploadData[0].bytes.toString('utf8') : '';
                              if (postBody) {
                                  const parsed = JSON.parse(postBody);
                                  if (parsed.username && parsed.username.trim()) {
                                      attemptedUsername = parsed.username.trim();
                                  }
                              }
                          } catch (e) {}
                      }
                      callback({});
                  }
              );
          } catch (e) {}

          const authUrl = 'https://authentication.quantal-labs.com/login?redirect=' + encodeURIComponent('http://localhost:3000/quantal-callback');
          authWindow.loadURL(authUrl);

          const completeLogin = async (candidateName) => {
              if (resolved) return;
              resolved = true;
              console.log("DEBUG: Quantal Labs login successful!");

              let finalUsername = candidateName || attemptedUsername;
              if (!finalUsername || finalUsername === 'QuantalUser') {
                  try {
                      const uname = await authWindow.webContents.executeJavaScript("window._lastAttemptedUsername || document.getElementById('username')?.value || ''");
                      if (uname && uname.trim()) {
                          finalUsername = uname.trim();
                      }
                  } catch (e) {}
              }

              if (finalUsername && finalUsername.trim()) {
                  quantalUsername = finalUsername.trim();
              }

              isAuthenticated = true;
              authProvider = 'quantal';
              saveSession({ 
                  provider: 'quantal', 
                  quantalUsername: quantalUsername,
                  user: { name: quantalUsername } 
              });

              if (!authWindow.isDestroyed()) {
                  authWindow.close();
              }
              if (mainWindow && !mainWindow.isDestroyed()) {
                  mainWindow.webContents.send('auth-update', { 
                      isLoggedIn: true, 
                      provider: 'quantal', 
                      user: { name: quantalUsername } 
                  });
              }
              resolve({ isLoggedIn: true, user: { name: quantalUsername } });
          };

          const checkUrlForSuccess = (url) => {
              if (!url) return false;
              if (url.includes('quantal-callback')) {
                  completeLogin(attemptedUsername);
                  return true;
              }
              try {
                  const parsed = new URL(url);
                  // If redirected away from authentication page to main quantal-labs site
                  if (parsed.hostname.toLowerCase() === 'quantal-labs.com' && !parsed.hostname.includes('authentication')) {
                      completeLogin(attemptedUsername);
                      return true;
                  }
              } catch (e) {}
              return false;
          };

          authWindow.webContents.on('will-navigate', (event, url) => {
              if (checkUrlForSuccess(url)) {
                  event.preventDefault();
              }
          });

          authWindow.webContents.on('will-redirect', (event, url) => {
              if (checkUrlForSuccess(url)) {
                  event.preventDefault();
              }
          });

          authWindow.webContents.on('did-navigate', (event, url) => {
              checkUrlForSuccess(url);
          });

          // ONLY trigger successful login if the actual POST /login request succeeds (statusCode 200)
          try {
              const filter = { urls: ['https://authentication.quantal-labs.com/login*'] };
              quantalSession.webRequest.onCompleted(filter, (details) => {
                  if (details.method === 'POST' && details.statusCode === 200) {
                      console.log("DEBUG: Quantal Labs POST /login returned 200 OK");
                      setTimeout(() => completeLogin(attemptedUsername), 400);
                  }
              });
          } catch (e) {}

          authWindow.on('closed', () => {
              if (!resolved) {
                  resolved = true;
                  console.log("DEBUG: Quantal Labs auth window closed without completing login");
                  resolve({ isLoggedIn: false, error: 'Sign-in window was closed without completing sign-in' });
              }
          });
      });
  });

  ipcMain.handle('pollinations-login', async () => {
      return new Promise((resolve) => {
          let resolved = false;
          let polliServer = null;

          const POLLI_PORT = 3002;
          const redirectUri = `http://localhost:${POLLI_PORT}/pollinations-callback`;
          const authUrl = `https://enter.pollinations.ai/authorize?redirect_uri=${encodeURIComponent(redirectUri)}&redirect_url=${encodeURIComponent(redirectUri)}&scope=usage`;

          // ─── Helpers ──────────────────────────────────────────────────────────

          const extractKeyFromText = (text) => {
              if (!text) return null;
              const match = text.match(/(?:plln_)?(?:sk_|pk_)[a-zA-Z0-9_-]{12,}/);
              return match ? match[0] : null;
          };

          const handleKeyFound = (key) => {
              if (resolved || !key) return;
              resolved = true;
              console.log('DEBUG: Pollinations.ai API Key acquired:', key.substring(0, 7) + '...');
              pollinationsApiKey = key;
              saveSession({
                  provider: authProvider,
                  pollinationsApiKey: key,
                  quantalUsername: quantalUsername,
                  user: { name: quantalUsername }
              });
              try { if (polliServer && polliServer.listening) polliServer.close(); } catch (e) {}
              resolve({ success: true, apiKey: key });
          };

          const checkUrlForKey = (url) => {
              if (!url) return false;
              try {
                  const urlObj = new URL(url);
                  if (urlObj.hash) {
                      const hashParams = new URLSearchParams(urlObj.hash.replace(/^#/, ''));
                      const key = hashParams.get('api_key') || hashParams.get('key') || hashParams.get('token') || hashParams.get('code');
                      if (key) { handleKeyFound(key); return true; }
                  }
                  const keyFromQuery = urlObj.searchParams.get('api_key') || urlObj.searchParams.get('key') || urlObj.searchParams.get('token') || urlObj.searchParams.get('code');
                  if (keyFromQuery) { handleKeyFound(keyFromQuery); return true; }
              } catch (e) {}
              const keyMatch = extractKeyFromText(url);
              if (keyMatch && url.includes('pollinations-callback')) { handleKeyFound(keyMatch); return true; }
              return false;
          };

          // ─── Local HTTP Server on port 3002 ───────────────────────────────────
          // Catches the pollinations-callback redirect from the system browser.
          // We serve an HTML page that reads the hash fragment and POSTs the key
          // back, because browsers do NOT include # fragments in HTTP requests.

          polliServer = http.createServer((req, cbRes) => {
              const reqUrl = new URL(req.url, `http://localhost:${POLLI_PORT}`);
              console.log('DEBUG: Pollinations callback server received:', req.url);

              if (req.method === 'POST' && reqUrl.pathname === '/pollinations-key') {
                  let body = '';
                  req.on('data', (chunk) => { body += chunk; });
                  req.on('end', () => {
                      cbRes.writeHead(200, {
                          'Content-Type': 'text/plain',
                          'Access-Control-Allow-Origin': '*'
                      });
                      cbRes.end('ok');
                      try {
                          const parsed = JSON.parse(body);
                          if (parsed.api_key) handleKeyFound(parsed.api_key);
                          else if (parsed.key) handleKeyFound(parsed.key);
                      } catch (e) {}
                  });
                  return;
              }

              if (req.method === 'OPTIONS') {
                  cbRes.writeHead(204, {
                      'Access-Control-Allow-Origin': '*',
                      'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
                      'Access-Control-Allow-Headers': 'Content-Type'
                  });
                  cbRes.end();
                  return;
              }

              if (checkUrlForKey(req.url)) {
                  cbRes.writeHead(200, { 'Content-Type': 'text/html' });
                  cbRes.end('<!DOCTYPE html><html><body><script>window.close();</script><p>✅ Authenticated! You can close this tab.</p></body></html>');
                  return;
              }

              if (reqUrl.pathname === '/pollinations-callback') {
                  cbRes.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
                  cbRes.end(`<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Aurora BioSpace – Signing In</title>
<style>
  body { background: #0f172a; color: #94a3b8; font-family: system-ui, sans-serif;
         display:flex; align-items:center; justify-content:center; height:100vh; margin:0; }
  .box { background:#1e293b; padding:32px; border-radius:14px; text-align:center; max-width:360px; }
  h2 { color:#38bdf8; margin:0 0 10px; }
  p { margin:0 0 6px; font-size:14px; }
</style>
</head>
<body>
<div class="box">
  <h2>✅ Almost there…</h2>
  <p>Finishing sign-in with Pollinations.ai.</p>
  <p id="st">Reading credentials…</p>
</div>
<script>
(function() {
  var PORT = ${POLLI_PORT};
  function tryHash() {
    var hash = window.location.hash.replace(/^#/, '');
    if (hash) {
      var params = new URLSearchParams(hash);
      var key = params.get('api_key') || params.get('key') || params.get('token') || params.get('code');
      if (key) { sendKey(key); return; }
    }
    var qParams = new URLSearchParams(window.location.search);
    var qKey = qParams.get('api_key') || qParams.get('key') || qParams.get('token') || qParams.get('code');
    if (qKey) { sendKey(qKey); return; }
    var m = window.location.href.match(/(?:plln_)?(?:sk_|pk_)[a-zA-Z0-9_-]{12,}/);
    if (m) { sendKey(m[0]); return; }
    document.getElementById('st').textContent = 'No key found in URL – you can close this tab.';
  }
  function sendKey(key) {
    document.getElementById('st').textContent = 'Authenticated! Returning to Aurora BioSpace…';
    fetch('http://localhost:' + PORT + '/pollinations-key', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ api_key: key })
    }).then(function() {
      document.getElementById('st').textContent = '✅ Done! You can close this tab.';
      setTimeout(function() { window.close(); }, 1500);
    }).catch(function() {
      document.getElementById('st').textContent = 'Could not reach Aurora BioSpace. Copy your key manually if needed.';
    });
  }
  tryHash();
  window.addEventListener('hashchange', tryHash);
})();
</script>
</body>
</html>`);
                  return;
              }

              cbRes.writeHead(404);
              cbRes.end('Not found');
          });

          polliServer.on('error', (err) => {
              console.error('DEBUG: Pollinations callback server error:', err.message);
              if (!resolved) {
                  resolved = true;
                  resolve({ success: false, error: err.message });
              }
          });

          polliServer.listen(POLLI_PORT, () => {
              console.log(`DEBUG: Pollinations callback server listening on port ${POLLI_PORT}`);

              // Open auth URL directly in the default system browser — no Electron popup.
              // This ensures passkeys (Touch ID, Windows Hello, security keys) work natively.
              openExternalCrossPlatform(authUrl);

              // Notify the renderer so it can show a "waiting" state in the UI
              if (mainWindow && !mainWindow.isDestroyed()) {
                  mainWindow.webContents.send('pollinations-browser-opened');
              }

              // Time-out after 5 minutes if the user never completes the flow
              const timeout = setTimeout(() => {
                  if (!resolved) {
                      resolved = true;
                      try { if (polliServer && polliServer.listening) polliServer.close(); } catch (e) {}
                      resolve({ success: false, cancelled: true, timeout: true });
                  }
              }, 300000);
              // Prevent the timeout from blocking Node's event loop shutdown
              if (timeout.unref) timeout.unref();
          });
      });
  });

  ipcMain.handle('set-pollinations-key', async (event, key) => {
      if (key && key.trim()) {
          pollinationsApiKey = key.trim();
          saveSession({ provider: authProvider, pollinationsApiKey: pollinationsApiKey, quantalUsername: quantalUsername, user: { name: quantalUsername } });
          return { success: true };
      }
      return { success: false };
  });

  ipcMain.handle('google-oauth-logout', async () => {
    isAuthenticated = false;
    authProvider = null;
    pollinationsApiKey = null;
    clearSession();
    oAuth2Client.credentials = {}; // Clear credentials
    return { isLoggedIn: false };
  });

  ipcMain.handle('get-access-token', async () => {
    if (!isAuthenticated || !oAuth2Client.credentials || !oAuth2Client.credentials.access_token) return null;
    return oAuth2Client.credentials.access_token;
  });

  // --- RATE LIMITER QUEUE ---
  let isProcessing = false;
  const requestQueue = [];

  async function processQueue() {
    if (isProcessing || requestQueue.length === 0) return;
    isProcessing = true;

    const { prompt, resolve, reject } = requestQueue.shift();
    const models = ['gemini-flash-latest', 'gemini-3.1-flash-lite'];
    let currentModelIndex = 0;

    async function attemptRequest(modelIndex) {
        const model = models[modelIndex];
        try {
            const accessToken = oAuth2Client.credentials.access_token;
            if (!accessToken) {
                throw new Error("No access token available.");
            }
            const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${accessToken}` },
                body: JSON.stringify({ 
                    contents: [{ role: 'user', parts: [{ text: prompt }] }]
                })
            });
            const data = await response.json();
            
            if (data.error) {
                const isRateLimited = data.error.code === 429;
                const isHighDemand = data.error.message && data.error.message.includes('high demand');
                const isQuotaExceeded = data.error.message && data.error.message.includes('exceeded your current quota');
                
                if ((isRateLimited || isHighDemand || isQuotaExceeded) && modelIndex < models.length - 1) {
                    console.warn(`Issue on ${model} (code: ${data.error.code}, msg: ${data.error.message}), falling back to ${models[modelIndex + 1]}`);
                    return attemptRequest(modelIndex + 1);
                }
                throw new Error(data.error.message);
            }
            return { success: true, text: data.candidates?.[0]?.content?.parts?.[0]?.text };
        } catch (err) {
            throw err;
        }
    }

    try {
        const result = await attemptRequest(currentModelIndex);
        resolve(result);
    } catch (err) {
        reject(err);
    } finally {
        isProcessing = false;
        setTimeout(() => processQueue(), 2000); 
    }
  }

  ipcMain.handle('gemini:chat', async (event, prompt) => {
    if (!isAuthenticated) return { success: false, error: 'Not authenticated' };
    
    if (authProvider === 'quantal') {
        try {
            const payload = {
                model: 'openai',
                messages: [{ role: 'user', content: `${prompt} Answer directly in plain text. Do not provide code, images, search results, or HTML.` }]
            };
            const headers = { 'Content-Type': 'application/json' };
            if (pollinationsApiKey) {
                headers['Authorization'] = `Bearer ${pollinationsApiKey}`;
            }
            const fetchUrl = pollinationsApiKey
                ? `https://text.pollinations.ai/?key=${encodeURIComponent(pollinationsApiKey)}`
                : 'https://text.pollinations.ai/';

            const response = await fetch(fetchUrl, {
                method: 'POST',
                headers: headers,
                body: JSON.stringify(payload)
            });
            let text = await response.text();
            // Aggressively strip potential HTML tags and extra whitespace
            text = text.replace(/<[^>]*>?/gm, '').trim();
            return { success: true, text: text };
        } catch (err) {
            return { success: false, error: err.message };
        }
    }

    return new Promise((resolve, reject) => {
      requestQueue.push({ prompt, resolve, reject });
      processQueue();
    });
  });
  ipcMain.on('window-control', (event, action) => {
    const window = BrowserWindow.fromWebContents(event.sender);
    if (!window) return;
    if (action === 'close') window.close();
    if (action === 'minimize') window.minimize();
    if (action === 'maximize') window.isMaximized() ? window.unmaximize() : window.maximize();
  });
}
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
