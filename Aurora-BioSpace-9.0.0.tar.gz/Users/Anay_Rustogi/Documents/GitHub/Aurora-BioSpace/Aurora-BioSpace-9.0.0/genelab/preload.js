const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
    loginWithGoogle: () => ipcRenderer.invoke('google-oauth-login'),
    loginWithGoogleBrowser: () => ipcRenderer.invoke('google-browser-oauth-login'),
    loginWithQuantal: () => ipcRenderer.invoke('quantal-oauth-login'),
    loginWithPollinations: () => ipcRenderer.invoke('pollinations-login'),
    setPollinationsKey: (key) => ipcRenderer.invoke('set-pollinations-key', key),
    getAuthStatus: () => ipcRenderer.invoke('get-auth-status'),
    getAccessToken: () => ipcRenderer.invoke('get-access-token'),
    chatGemini: (prompt) => ipcRenderer.invoke('gemini:chat', prompt),
    logout: () => ipcRenderer.invoke('google-oauth-logout'),
    onAuthUpdate: (callback) => ipcRenderer.on('auth-update', (event, status) => callback(status)),
    onPollinationsBrowserOpened: (callback) => ipcRenderer.on('pollinations-browser-opened', () => callback())
});

window.addEventListener('DOMContentLoaded', () => {
    const replaceText = (selector, text) => {
        const element = document.getElementById(selector);
        if (element) element.innerText = text;
    };

    for (const type of ['chrome', 'node', 'electron']) {
        replaceText(`${type}-version`, process.versions[type]);
    }
});