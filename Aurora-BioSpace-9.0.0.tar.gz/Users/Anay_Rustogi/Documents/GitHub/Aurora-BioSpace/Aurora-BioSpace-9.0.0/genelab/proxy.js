const fs = require('fs');
const util = require('util');
const path = require('path');

const LOG_FILE = path.join(__dirname, 'proxy.log');
const LOG_BACKUP = path.join(__dirname, 'proxy.log.bak');
const MAX_LOG_BYTES = 5 * 1024 * 1024; // 5 MB max per log file

let currentLogStream = null;
let bytesWrittenSinceCheck = 0;

function getLogStream() {
    try {
        if (!currentLogStream || bytesWrittenSinceCheck > 100000) {
            bytesWrittenSinceCheck = 0;
            if (fs.existsSync(LOG_FILE)) {
                const stat = fs.statSync(LOG_FILE);
                if (stat.size >= MAX_LOG_BYTES) {
                    if (currentLogStream) {
                        try { currentLogStream.end(); } catch (e) {}
                        currentLogStream = null;
                    }
                    if (fs.existsSync(LOG_BACKUP)) {
                        try { fs.unlinkSync(LOG_BACKUP); } catch (e) {}
                    }
                    try { fs.renameSync(LOG_FILE, LOG_BACKUP); } catch (e) {}
                }
            }
        }
    } catch (e) {}

    if (!currentLogStream) {
        currentLogStream = fs.createWriteStream(LOG_FILE, { flags: 'a' });
    }
    return currentLogStream;
}

// Redirect console.log and console.error to the log file with size limit
console.log = function () {
    const text = util.format.apply(null, arguments) + '\n';
    bytesWrittenSinceCheck += text.length;
    try { getLogStream().write(text); } catch (e) {}
    process.stdout.write(text);
};
console.error = function () {
    const text = util.format.apply(null, arguments) + '\n';
    bytesWrittenSinceCheck += text.length;
    try { getLogStream().write(text); } catch (e) {}
    process.stderr.write(text);
};

// Network-level errors that are transient and should NOT crash the proxy process
const RECOVERABLE_CODES = new Set([
    'ECONNRESET', 'EPIPE', 'ECONNABORTED', 'ETIMEDOUT',
    'ENOTFOUND', 'EAI_AGAIN', 'EHOSTUNREACH', 'ENETUNREACH'
]);

// Global error handlers — only exit on truly fatal errors
process.on('uncaughtException', (err) => {
    if (RECOVERABLE_CODES.has(err.code)) {
        console.error('Recoverable network error (proxy kept alive):', err.message);
        return; // Don't exit — keep the proxy running
    }
    console.error('UNCAUGHT EXCEPTION:', err);
    process.exit(1);
});
process.on('unhandledRejection', (reason) => {
    const code = reason && reason.code;
    if (RECOVERABLE_CODES.has(code)) {
        console.error('Recoverable unhandled rejection (proxy kept alive):', reason.message || reason);
        return;
    }
    console.error('UNHANDLED REJECTION:', reason);
    process.exit(1);
});

const express = require('express');
const cors = require('cors');
const myFetch = require('node-fetch');

const app = express();
const PORT = 3001;

app.use(cors());
app.use(express.json());

// Define the GeneLab API base URL
const GENELAB_API_BASE = 'https://osdr.nasa.gov/osdr/data/search';

/**
 * Fetch with automatic retry on transient network errors.
 * @param {string} url
 * @param {object} options
 * @param {number} retries
 */
async function fetchWithRetry(url, options = {}, retries = 3) {
    let lastErr;
    for (let attempt = 1; attempt <= retries; attempt++) {
        try {
            const response = await myFetch(url, {
                ...options,
                // Give each attempt a 15-second timeout
                timeout: 15000
            });
            return response;
        } catch (err) {
            lastErr = err;
            const isRecoverable = RECOVERABLE_CODES.has(err.code) ||
                err.message.includes('connection reset') ||
                err.message.includes('stream reading error');
            if (isRecoverable && attempt < retries) {
                const delay = 500 * attempt; // 500ms, 1000ms back-off
                console.error(`Attempt ${attempt} failed (${err.code || err.message}), retrying in ${delay}ms...`);
                await new Promise(r => setTimeout(r, delay));
                continue;
            }
            throw err;
        }
    }
    throw lastErr;
}

// Proxy endpoint
app.get('/proxy-genelab', async (req, res) => {
    const searchTerm = req.query.term || '';
    const apiUrlWithParams = `${GENELAB_API_BASE}?term=${encodeURIComponent(searchTerm)}&size=100`;
    console.log(`Proxy calling NASA API: ${apiUrlWithParams}`);

    try {
        const response = await fetchWithRetry(apiUrlWithParams, {
            headers: { 'User-Agent': 'AuroraBioscienceDashboard/1.0' }
        });
        if (!response.ok) {
            console.error(`NASA API responded with status: ${response.status}`);
            const errorText = await response.text();
            console.error(`NASA API error response: ${errorText}`);
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        res.json(data);
    } catch (error) {
        console.error('Proxy error:', error.message || error);
        if (!res.headersSent) {
            res.status(502).json({ error: 'Failed to fetch data from NASA API. Please try again.' });
        }
    }
});

// Handle socket-level errors on the express server itself
const server = app.listen(PORT, (err) => {
    if (err) {
        console.error('Failed to listen on port', PORT, err);
        process.exit(1);
    }
    console.log(`Proxy server listening on port ${PORT}`);
});

server.on('error', (err) => {
    if (RECOVERABLE_CODES.has(err.code)) {
        console.error('Recoverable server socket error:', err.message);
        return;
    }
    console.error('Fatal server error:', err);
    process.exit(1);
});
