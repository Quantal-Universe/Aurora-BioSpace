const { ipcRenderer, webFrame } = require('electron');

// Script evaluated directly in the webpage's main world (world 0) to detect passkey prompts
const passkeyDetectionScript = `
(function() {
    var passkeyDetected = false;

    function notifyPasskey(reason) {
        if (passkeyDetected) return;
        passkeyDetected = true;
        console.log("DEBUG: Google Passkey detected via: " + reason);

        var detectedEmail = '';
        try {
            var emailEl = document.querySelector('[data-email]') || document.querySelector('div[email]');
            if (emailEl) detectedEmail = emailEl.getAttribute('data-email') || emailEl.getAttribute('email') || '';
            if (!detectedEmail && document.body) {
                var m = document.body.innerText.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}/);
                if (m) detectedEmail = m[0];
            }
        } catch(e) {}

        window.postMessage({
            type: 'AURORA_GOOGLE_PASSKEY_DETECTED',
            reason: reason,
            email: detectedEmail,
            url: window.location.href
        }, '*');
    }

    // 1. Intercept navigator.credentials.get
    if (navigator.credentials) {
        var origGet = navigator.credentials.get ? navigator.credentials.get.bind(navigator.credentials) : null;
        navigator.credentials.get = function(options) {
            console.log("DEBUG: navigator.credentials.get called:", options);
            if (options && options.publicKey) {
                notifyPasskey('credentials.get');
            }
            if (origGet) {
                return origGet(options);
            }
            return new Promise(function() {});
        };

        var origCreate = navigator.credentials.create ? navigator.credentials.create.bind(navigator.credentials) : null;
        navigator.credentials.create = function(options) {
            if (options && options.publicKey) {
                notifyPasskey('credentials.create');
            }
            if (origCreate) {
                return origCreate(options);
            }
            return new Promise(function() {});
        };
    }

    // 2. Scan DOM for Google's passkey screen text
    function checkDOM() {
        if (passkeyDetected) return;
        try {
            var text = document.body ? document.body.innerText : '';
            if (text.includes('Use your passkey') ||
                text.includes('fingerprint, face, or screen lock') ||
                text.includes('Make sure Bluetooth is on') ||
                window.location.href.includes('challenge/pk')) {
                notifyPasskey('dom_text');
            }
        } catch(e) {}
    }

    setInterval(checkDOM, 400);
    window.addEventListener('DOMContentLoaded', checkDOM);
    checkDOM();
})();
`;

try {
    webFrame.executeJavaScriptInIsolatedWorld(0, [{ code: passkeyDetectionScript }]);
} catch (e) {}

// Forward passkey detected message from main world to main process
window.addEventListener('message', (event) => {
    if (event.data && event.data.type === 'AURORA_GOOGLE_PASSKEY_DETECTED') {
        ipcRenderer.send('google-passkey-detected', event.data);
    }
});
